package com.OnlineGiftShopping.orderservice.helper;

public enum OrderStatus {

    Pending,

    Placed,

    Shipped,

    Delivered
}