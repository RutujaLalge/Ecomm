package com.OnlineGiftShopping.orderservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.OnlineGiftShopping.orderservice.dto.OrderDto;
import com.OnlineGiftShopping.orderservice.entity.Order;
import com.OnlineGiftShopping.orderservice.service.OrderService;

import java.util.List;

@RestController
@RequestMapping("/orders")
public class OrderController {

    @Autowired
    private OrderService orderService;

    @PostMapping("/create")
    public ResponseEntity<Order> createOrder(@RequestBody OrderDto orderDto) {
        Order createdOrder = this.orderService.createOrder(orderDto);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdOrder);
    }

    @GetMapping("/getAll")
    public ResponseEntity<List<Order>> getAllOrders() {
        List<Order> orders = this.orderService.getAllOrders();
        return ResponseEntity.ok(orders);
    }

    @GetMapping("get/{id}")
    public ResponseEntity<Order> getOrderById(@PathVariable Long id) {

            Order order = this.orderService.getOrderById(id);
            return ResponseEntity.ok(order);

    }

    @PutMapping("/update/{id}")
    public ResponseEntity<Order> updateOrder(@PathVariable Long id, @RequestBody OrderDto orderDto) {

            Order updatedOrder = this.orderService.updateOrder(id, orderDto);
            return ResponseEntity.ok(updatedOrder);

    }

    @DeleteMapping("delete/{id}")
    public ResponseEntity<Void> deleteOrderById(@PathVariable Long id) {

           this.orderService.deleteOrderById(id);
            return ResponseEntity.noContent().build();

    }
}
