package com.OnlineGiftShopping.orderservice.service;

import java.util.List;

import com.OnlineGiftShopping.orderservice.dto.OrderDto;
import com.OnlineGiftShopping.orderservice.entity.Order;

public interface OrderService {

    //create
    Order createOrder(OrderDto orderDto);

    //getAll
    List<Order> getAllOrders();

    //getOrderById
    Order getOrderById(Long id);

    //updateOrder
    Order updateOrder(Long id, OrderDto orderDto);

    //deleteOrder
    void deleteOrderById(Long id);
}

