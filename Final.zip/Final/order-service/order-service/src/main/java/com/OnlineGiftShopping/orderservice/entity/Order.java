package com.OnlineGiftShopping.orderservice.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.UUID;

import com.OnlineGiftShopping.orderservice.helper.OrderStatus;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name="orders")
public class Order {

        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        private Long id;

        @NotBlank(message = "Order description is required")
        @Size(max = 255, message = "Order description must be less than 255 characters")
        private String orderDescription;

        @NotNull(message = "Date is required")
        private Date date;

        @NotNull(message = "Amount is required")
        @Min(value = 0, message = "Amount must be greater than or equal to zero")
        private Long amount;

        @NotBlank(message = "Address is required")
        @Size(max = 255, message = "Address must be less than 255 characters")
        private String address;


        @NotNull(message = "Order status is required")
        @Enumerated(EnumType.STRING)
        private OrderStatus orderStatus;

        @NotNull(message = "Total amount is required")
        @Min(value = 0, message = "Total amount must be greater than or equal to zero")
        private Long totalAmount;

        @Min(value = 0, message = "Discount must be greater than or equal to zero")
        private Long discount;

        @NotNull(message = "Tracking ID is required")
        private UUID trackingId;

		public Long getId() {
			return id;
		}

		public void setId(Long id) {
			this.id = id;
		}

		public String getOrderDescription() {
			return orderDescription;
		}

		public void setOrderDescription(String orderDescription) {
			this.orderDescription = orderDescription;
		}

		public Date getDate() {
			return date;
		}

		public void setDate(Date date) {
			this.date = date;
		}

		public Long getAmount() {
			return amount;
		}

		public void setAmount(Long amount) {
			this.amount = amount;
		}

		public String getAddress() {
			return address;
		}

		public void setAddress(String address) {
			this.address = address;
		}

		public OrderStatus getOrderStatus() {
			return orderStatus;
		}

		public void setOrderStatus(OrderStatus orderStatus) {
			this.orderStatus = orderStatus;
		}

		public Long getTotalAmount() {
			return totalAmount;
		}

		public void setTotalAmount(Long totalAmount) {
			this.totalAmount = totalAmount;
		}

		public Long getDiscount() {
			return discount;
		}

		public void setDiscount(Long discount) {
			this.discount = discount;
		}

		public UUID getTrackingId() {
			return trackingId;
		}

		public void setTrackingId(UUID trackingId) {
			this.trackingId = trackingId;
		}

        @NotNull(message = "User is required")
        @OneToOne(cascade = CascadeType.MERGE)
        @JoinColumn(name = "user_id", referencedColumnName = "id")
        	private User user;
//////
////        @OneToMany(fetch = FetchType.LAZY, mappedBy = "order")
////        private List<CartItems> cartItems;
      
        
        
     

}

