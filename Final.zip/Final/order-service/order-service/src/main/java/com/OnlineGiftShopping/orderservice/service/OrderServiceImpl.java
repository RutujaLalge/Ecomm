package com.OnlineGiftShopping.orderservice.service;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.OnlineGiftShopping.orderservice.dto.OrderDto;
import com.OnlineGiftShopping.orderservice.entity.Order;
import com.OnlineGiftShopping.orderservice.exception.OrderNotFoundException;
import com.OnlineGiftShopping.orderservice.repository.OrderRepo;

import java.util.List;

@Service
public class OrderServiceImpl implements OrderService {

        @Autowired
        private OrderRepo orderRepo;


    @Override
    public Order createOrder(OrderDto orderDto) {
        Order order = new Order();
        BeanUtils.copyProperties(orderDto, order);
        Order createdOrder = this.orderRepo.save(order);
        return createdOrder;
    }

        @Override
        public List<Order> getAllOrders() {
        List<Order> orders = this.orderRepo.findAll();
        return orders;
    }

        @Override
        public Order getOrderById(Long id) {
            Order order = this.orderRepo.findById(id)
                    .orElseThrow(() -> new OrderNotFoundException("Order with id " + id + " not found"));
            return order;
        }

        @Override
        public Order updateOrder(Long id, OrderDto orderDto) {
            Order existingOrder =this.orderRepo.findById(id)
                    .orElseThrow(() -> new OrderNotFoundException("Order with id " + id + " not found"));
          existingOrder.setOrderDescription(orderDto.getOrderDescription());
          existingOrder.setOrderStatus(orderDto.getOrderStatus());
          existingOrder.setDate(orderDto.getDate());
          existingOrder.setAmount(orderDto.getAmount());
          existingOrder.setAddress(orderDto.getAddress());
          existingOrder.setDiscount(orderDto.getDiscount());
          existingOrder.setOrderStatus(orderDto.getOrderStatus());
          existingOrder.setTotalAmount(orderDto.getTotalAmount());
          existingOrder.setTrackingId(orderDto.getTrackingId());
            return orderRepo.save(existingOrder);
        }

        @Override
        public void deleteOrderById(Long id) {
            Order order = this.orderRepo.findById(id)
                    .orElseThrow(() -> new OrderNotFoundException("Order with id " + id + " not found"));
            orderRepo.delete(order);
        }
}
