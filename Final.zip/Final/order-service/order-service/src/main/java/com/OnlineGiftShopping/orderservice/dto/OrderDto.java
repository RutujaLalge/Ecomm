package com.OnlineGiftShopping.orderservice.dto;

import lombok.Data;

import java.util.Date;
import java.util.UUID;

import com.OnlineGiftShopping.orderservice.helper.OrderStatus;


@Data
public class OrderDto {

    private Long id;

    private String orderDescription;


    private Date date;


    private Long amount;


    private String address;


    private OrderStatus orderStatus;


    private Long totalAmount;


    private Long discount;


    private UUID trackingId;


	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}


	public String getOrderDescription() {
		return orderDescription;
	}


	public void setOrderDescription(String orderDescription) {
		this.orderDescription = orderDescription;
	}


	public Date getDate() {
		return date;
	}


	public void setDate(Date date) {
		this.date = date;
	}


	public Long getAmount() {
		return amount;
	}


	public void setAmount(Long amount) {
		this.amount = amount;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	public OrderStatus getOrderStatus() {
		return orderStatus;
	}


	public void setOrderStatus(OrderStatus orderStatus) {
		this.orderStatus = orderStatus;
	}


	public Long getTotalAmount() {
		return totalAmount;
	}


	public void setTotalAmount(Long totalAmount) {
		this.totalAmount = totalAmount;
	}


	public Long getDiscount() {
		return discount;
	}


	public void setDiscount(Long discount) {
		this.discount = discount;
	}


	public UUID getTrackingId() {
		return trackingId;
	}


	public void setTrackingId(UUID trackingId) {
		this.trackingId = trackingId;
	}
    
    
    
}
