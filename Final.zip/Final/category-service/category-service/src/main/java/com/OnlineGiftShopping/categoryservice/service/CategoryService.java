package com.OnlineGiftShopping.categoryservice.service;

import java.util.List;

import com.OnlineGiftShopping.categoryservice.dto.CategoryDto;
import com.OnlineGiftShopping.categoryservice.entity.Category;

public interface CategoryService {

    //create
    Category createCategory(CategoryDto categoryDTO);

    //getById
    Category getCategoryById(Long id);

    //getAll
    List<Category> getAllCategories();

    //update
    Category updateCategory(Long id, CategoryDto categoryDTO);

    //delete
    void deleteCategory(Long id);

}
