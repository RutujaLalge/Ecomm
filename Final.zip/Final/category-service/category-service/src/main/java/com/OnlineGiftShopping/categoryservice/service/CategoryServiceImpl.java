package com.OnlineGiftShopping.categoryservice.service;

import jakarta.ws.rs.NotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.OnlineGiftShopping.categoryservice.dto.CategoryDto;
import com.OnlineGiftShopping.categoryservice.entity.Category;
import com.OnlineGiftShopping.categoryservice.exception.CategoryNotFoundException;
import com.OnlineGiftShopping.categoryservice.repository.CategoryRepo;

import java.util.List;

@Service
public class CategoryServiceImpl implements CategoryService{

    @Autowired
     private CategoryRepo categoryRepo;
    @Override
    public Category createCategory(CategoryDto categoryDTO) {
        Category category=new Category();
        Category createdCategory = this.categoryRepo.save(category);
        return createdCategory;
    }

    @Override
    public Category getCategoryById(Long id) {
        Category category = this.categoryRepo.findById(id)
                .orElseThrow(() -> new CategoryNotFoundException("Category not found with id: " + id));
        return category;
    }

    @Override
    public List<Category> getAllCategories() {
        List<Category> categories = this.categoryRepo.findAll();
        return categories;
    }

    @Override
    public Category updateCategory(Long id, CategoryDto categoryDTO) {
        Category existingCategory = this.categoryRepo.findById(id)
                .orElseThrow(() -> new CategoryNotFoundException("Category not found with id: " + id));
        existingCategory.setName(categoryDTO.getName());
        existingCategory.setDescription(categoryDTO.getDescription());
        Category updatedCategory = this.categoryRepo.save(existingCategory);
        return updatedCategory;
    }

    @Override
    public void deleteCategory(Long id) {
        Category category = this.categoryRepo.findById(id)
                .orElseThrow(() -> new CategoryNotFoundException("Category not found with id: " + id));
        this.categoryRepo.delete(category);
    }
}

