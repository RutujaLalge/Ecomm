package com.OnlineGiftShopping.cartservice;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
//import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.OnlineGiftShopping.cartservice.entity.Cart;
import com.OnlineGiftShopping.cartservice.repository.CartRepo;
import com.OnlineGiftShopping.cartservice.service.CartService;
import com.OnlineGiftShopping.cartservice.service.CartServiceImpl;


@SpringBootTest(classes = {CartServiceTest.class})
public class CartServiceTest {
	
	@Mock
	 private CartRepo cartRepo; 
	 
	 @InjectMocks
	 CartServiceImpl cartServiceImpl;
	 
	 @Test
	  public void testGetCartById() {
	        Long id = 1L;
	        Cart cart = new Cart();
	        cart.setId(id);
	        cart.setPrice(50L);
	        cart.setQuantity(2L);

	        when(cartRepo.findById(id)).thenReturn(Optional.of(cart));

	        Cart result = cartServiceImpl.getCartById(id);
	        //assertEquals(5, result.getId());
	        assertEquals(cart.getId(), result.getId());
	        assertEquals(cart.getPrice(), result.getPrice());
	        assertEquals(cart.getQuantity(), result.getQuantity());
	    }
	 
	 

}
