package com.OnlineGiftShopping.cartservice.service;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.OnlineGiftShopping.cartservice.dto.CartDto;
import com.OnlineGiftShopping.cartservice.entity.Cart;
import com.OnlineGiftShopping.cartservice.exception.CartNotFoundException;
import com.OnlineGiftShopping.cartservice.repository.CartRepo;

import java.util.List;

@Service
public class CartServiceImpl implements CartService {

    @Autowired
    private CartRepo cartRepo;


    @Override
    public Cart createCart(CartDto cartDTO) {
        Cart cart = new Cart();
        BeanUtils.copyProperties(cartDTO,cart);
        Cart createdCart = this.cartRepo.save(cart);
        return createdCart;
    }

    @Override
    public Cart updateCart(Long id, CartDto cartDTO) {
        Cart existingCart = this.cartRepo.findById(id)
                .orElseThrow(() -> new CartNotFoundException("Cart not found with id: " + id));
        existingCart.setPrice(cartDTO.getPrice());
        existingCart.setQuantity(cartDTO.getQuantity());
        Cart updatedCart = this.cartRepo.save(existingCart);
        return updatedCart;
    }

    @Override
    public Cart getCartById(Long id) {
        Cart cart = this.cartRepo.findById(id)
                .orElseThrow(() -> new CartNotFoundException("Cart not found with id: " + id));
        return cart;
    }

    @Override
    public List<Cart> getAllCarts() {
        List<Cart> carts = this.cartRepo.findAll();
        
        return carts;
    }

    @Override
    public void deleteCart(Long id) {
        Cart cart = this.cartRepo.findById(id)
                .orElseThrow(() -> new CartNotFoundException("Cart not found with id: " + id));
        cartRepo.delete(cart);
    }
}

