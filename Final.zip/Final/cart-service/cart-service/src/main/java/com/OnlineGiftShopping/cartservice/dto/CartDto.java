package com.OnlineGiftShopping.cartservice.dto;

import lombok.Data;

@Data

public class CartDto {

    private Long id;


    private Long price;


    private Long quantity;


	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}


	public Long getPrice() {
		return price;
	}


	public void setPrice(Long price) {
		this.price = price;
	}


	public Long getQuantity() {
		return quantity;
	}


	public void setQuantity(Long quantity) {
		this.quantity = quantity;
	}


	public CartDto(Long id, Long price, Long quantity) {
		super();
		this.id = id;
		this.price = price;
		this.quantity = quantity;
	}    
    

}

