package com.OnlineGiftShopping.cartservice.service;

import java.util.List;

import com.OnlineGiftShopping.cartservice.dto.CartDto;
import com.OnlineGiftShopping.cartservice.entity.Cart;

public interface CartService {

    //create
    Cart createCart(CartDto cartDTO);

    //update
    Cart updateCart(Long id, CartDto cartDTO);

    //getById
    Cart getCartById(Long id);

    //getAll
    List<Cart> getAllCarts();

    //delete
    void deleteCart(Long id);

}
