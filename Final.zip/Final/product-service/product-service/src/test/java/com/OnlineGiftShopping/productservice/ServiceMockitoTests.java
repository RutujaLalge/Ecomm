package com.OnlineGiftShopping.productservice;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Optional;

import org.apache.http.HttpStatus;
import org.assertj.core.api.Assert;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;
//import org.springframework.util.Assert;

import com.OnlineGiftShopping.productservice.controller.ProductController;
import com.OnlineGiftShopping.productservice.entity.Product;
import com.OnlineGiftShopping.productservice.repository.ProductRepo;
import com.OnlineGiftShopping.productservice.service.ProductServiceImpl;

@SpringBootTest
public class ServiceMockitoTests {
    
    @Mock
    private ProductRepo productRepo;
    
    @InjectMocks
    private ProductServiceImpl productServiceImpl; 
    
    @Test
    public void testGetProductById() {
        
        
        Product p1 = new Product();
        Long id = 1L;
        p1.setId(1L);
        p1.setDescription("wertyui");
        p1.setImg(null);
        p1.setName("Frame");
        p1.setPrice(200L);
        
        
        
       
        when(productRepo.findById(id)).thenReturn(Optional.of(p1));
        
        Product result = productServiceImpl.getProductById(id);
        assertEquals(p1.getId(), result.getId());
        assertEquals(p1.getDescription(), result.getDescription());
        assertEquals(p1.getImg(), result.getImg());
        assertEquals(p1.getPrice(), result.getName());
        assertEquals(p1.getPrice(), result.getPrice());
       

    }
    
}
    
//    @Autowired
//    private  ProductController productController ;
//    
//    @Test
//    public void test()
//    {
////    	List<Product> res = this.productController.getAllProducts();
////    	Assert.assertEquals(5,res.size());
//    	
////    	ResponseEntity<List<Product>> res = this.productController.getAllProducts();
////    	//Assert.assertEquals(5,res.getStatusCode());
////    	Assert.assertEquals(5, res.ok());
//    	
//    	    ResponseEntity<List<Product>> responseEntity = this.productController.getAllProducts();
//    	    List<Product> products = responseEntity.getBody();
//    	    //Assert.assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
//    	    Assert.assertEquals(5, products.size());
//    	}
//
//    	
//    }

