package com.OnlineGiftShopping.productservice.service;

import java.util.List;

import com.OnlineGiftShopping.productservice.dto.ProductDto;
import com.OnlineGiftShopping.productservice.entity.Product;

public interface ProductService {

    //create
    Product createProduct(ProductDto productDto);

    //getAll
    List<Product> getAllProducts();

    //getById
    Product getProductById(long id);
    
//    //getProductByUserId
//    List<Product>getProductByUserId(long userId);

    //update
    Product updateProduct(long id, ProductDto productDto);

    //delete
    void deleteProductById(long id);
}

