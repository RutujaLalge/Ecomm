package com.OnlineGiftShopping.productservice.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name="products")
public class Product {

        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        private Long id;
        
		@NotBlank(message = "Name is required")
        @Size(max = 255, message = "Name must be less than 255 characters")
        private String name;

        @NotNull(message = "Price is required")
        @Min(value = 0, message = "Price must be greater than or equal to zero")
        private Long price;

        @NotBlank(message = "Description is required")
        @Size(max = 1000, message = "Description must be less than 1000 characters")
        private String description;

        @NotNull(message = "Image is required")
        private byte[] img;

		

		public Long getId() {
			return id;
		}

		public void setId(Long id) {
			this.id = id;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public Long getPrice() {
			return price;
		}
		

		public void setPrice(Long price) {
			this.price = price;
		}

		public String getDescription() {
			return description;
		}

		public void setDescription(String description) {
			this.description = description;
		}

		public byte[] getImg() {
			return img;
		}

		public void setImg(byte[] img) {
			this.img = img;
		}

//		public Product() {
//			super();
//			this.id = id;
//			this.name = name;
//			this.price = price;
//			this.description = description;
//			this.img = img;
//		}
//		
		
		
		
//        @ManyToOne(fetch = FetchType.LAZY, optional=false)
//		@JoinColumn(name= "category_id", nullable=false)
//         private Category category;
        
      

}

