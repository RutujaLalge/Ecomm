package com.OnlineGiftShopping.productservice.controller;

import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.OnlineGiftShopping.productservice.dto.ProductDto;
import com.OnlineGiftShopping.productservice.entity.Product;
import com.OnlineGiftShopping.productservice.service.ProductService;

import java.util.List;

@RestController
@RequestMapping("/products")
public class ProductController {

    @Autowired
    private ProductService productService;

    @PostMapping("/create")
    public ResponseEntity<Product> createProduct(@Valid @RequestBody ProductDto productDto) {
        Product createdProduct = this.productService.createProduct(productDto);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdProduct);
    }

    @GetMapping("/getAll")
    public ResponseEntity<List<Product>> getAllProducts() {
        List<Product> products = this.productService.getAllProducts();
        return ResponseEntity.ok(products);
    }

    @GetMapping("get/{id}")
    public ResponseEntity<Product> getProductById(@PathVariable long id) {

            Product product = this.productService.getProductById(id);
            return ResponseEntity.ok(product);

    }

    @PutMapping("update/{id}")
    public ResponseEntity<Product> updateProduct(@PathVariable long id, @Valid @RequestBody ProductDto productDto) {

            Product updatedProduct = this.productService.updateProduct(id, productDto);
            return ResponseEntity.ok(updatedProduct);

    }

    @DeleteMapping("delete/{id}")
    public ResponseEntity<Void> deleteProductById(@PathVariable long id) {

            this.productService.deleteProductById(id);
            return ResponseEntity.noContent().build();

    }
    
    @GetMapping("/getProductById/{productId}")
    public Product getProductById(@PathVariable Long productId)
    {
    	return productService.getProductById(productId);
    	
    }
}
