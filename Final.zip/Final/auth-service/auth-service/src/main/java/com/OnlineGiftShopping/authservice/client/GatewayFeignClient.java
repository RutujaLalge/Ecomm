package com.OnlineGiftShopping.authservice.client;


import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.OnlineGiftShopping.authservice.dto.UserClientDTO;
 
@FeignClient(name = "api-gateway")
public interface GatewayFeignClient {
    @PostMapping("/client/create")
    public UserClientDTO create(@RequestBody UserClientDTO userClientDTO);
}
