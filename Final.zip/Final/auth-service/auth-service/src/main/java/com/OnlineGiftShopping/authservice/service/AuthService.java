package com.OnlineGiftShopping.authservice.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.OnlineGiftShopping.authservice.client.GatewayFeignClient;
import com.OnlineGiftShopping.authservice.dto.LoginResponse;
import com.OnlineGiftShopping.authservice.dto.UserClientDTO;
import com.OnlineGiftShopping.authservice.dto.UserCredentialDto;
import com.OnlineGiftShopping.authservice.dto.UserRegistrationDto;
import com.OnlineGiftShopping.authservice.entity.UserCredential;

import com.OnlineGiftShopping.authservice.repository.UserCredentialRepository;

@Service
public class AuthService {
	
	@Autowired
	private UserCredentialRepository userCredentialRepository;
	
	@Autowired
	private PasswordEncoder passwordEncoder;
	
	@Autowired
    private JwtService jwtService;
	
	public String saveUser(UserCredential userCredential)
	{
		userCredential.setPassword(passwordEncoder.encode(userCredential.getPassword()));
		userCredentialRepository.save(userCredential);
		return "User added to the system";
	}
	
	public String generateToken(String username) {
        return jwtService.generateToken(username);
    }

    public void validateToken(String token) {
        jwtService.validateToken(token);
    }

}


