package com.OnlineGiftShopping.userservice.entity;


import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
//import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
//@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name="userDetails")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @NotBlank(message = "Name is required")
    @Size(max = 50, message = "Name must be less than 50 characters")
    @Column(name = "Name", nullable = false, length = 50)
    private String name;


    @NotBlank(message = "Email is required")
    @Email(message = "Invalid email format")
    @Size(max = 50, message = "Email must be less than 50 characters")
    @Column(name = "Email", nullable = false, unique = true, length = 50)
    private String email;

    @Size(max = 15, message = "Phone number must be less than 15 characters")
    @Column(name = "phone_number", length = 15)
    private String phoneNumber;

    @Column(name = "Password", length = 30)
    @JsonIgnore
    private String password;
    
//    @Transient
//    private List<Product> getProducts=new ArrayList<>();
//
//	public List<Product> getGetProducts() {
//		return getProducts;
//	}
//
//	public void setGetProducts(List<Product> getProducts) {
//		this.getProducts = getProducts;
//	}
    
//    @ManyToOne(fetch = FetchType.LAZY)
//    @JoinColumn(name = "product_id") // Name of the foreign key column in the user table
//    private Product product;

//	public Product getProduct() {
//		return product;
//	}
//
//	public void setProduct(Product product) {
//		this.product = product;
//	}
	
	

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}



//    @OneToMany (mappedBy = "user")
//    @JsonIgnore
//    private List<Order> orders;
    
	

}

