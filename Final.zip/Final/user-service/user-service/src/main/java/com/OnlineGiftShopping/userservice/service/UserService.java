package com.OnlineGiftShopping.userservice.service;

import java.util.List;

import com.OnlineGiftShopping.userservice.dto.UserDemoDto;
import com.OnlineGiftShopping.userservice.dto.UserDto;
import com.OnlineGiftShopping.userservice.entity.User;

public interface UserService {

    //create
    User createUser(UserDto userDto);

    //getAll
    List<User> getAllUsers();

    //getUserById
    User getUserById(long id);
   

    //updateUser
    User updateUser(long id, UserDto userDto);
    

    //deleteUser
    void deleteUserById(long id);
    
    public UserDemoDto getProductByUserId(Long userId);
}

