package com.OnlineGiftShopping.userservice.dto;


import com.OnlineGiftShopping.userservice.entity.User;

public class UserDemoDto {
	
	private Long userId;
	
	private ProductDto productDto;
	
	private User user;

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public ProductDto getProductDto() {
		return productDto;
	}

	public void setProductDto(ProductDto productDto) {
		this.productDto = productDto;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public UserDemoDto(Long userId, ProductDto productDto, User user) {
		super();
		this.userId = userId;
		this.productDto = productDto;
		this.user = user;
	}
	
	
	
	

}	