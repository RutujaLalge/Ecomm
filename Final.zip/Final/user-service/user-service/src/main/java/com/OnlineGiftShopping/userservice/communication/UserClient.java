package com.OnlineGiftShopping.userservice.communication;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;


import com.OnlineGiftShopping.userservice.dto.ProductDto;
//import com.OnlineGiftShopping.userservice.entity.User;

@FeignClient(name="PRODUCT-SERVICE",url="http://localhost:9093")
public interface UserClient {
	
	
	@GetMapping("/products/getProductById/{productId}")
    public ProductDto getProductById(@PathVariable Long productId);
    
}
