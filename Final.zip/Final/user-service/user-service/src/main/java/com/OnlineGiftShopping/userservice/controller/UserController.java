package com.OnlineGiftShopping.userservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.OnlineGiftShopping.userservice.dto.UserDemoDto;
import com.OnlineGiftShopping.userservice.dto.UserDto;
import com.OnlineGiftShopping.userservice.entity.User;
import com.OnlineGiftShopping.userservice.service.UserService;

import java.util.List;

@RestController
@RequestMapping("/users")
public class UserController {

        @Autowired
        private UserService userService;

        @PostMapping("/create")
        public ResponseEntity<User> createUser(@RequestBody UserDto userDto) {

                User createdUser = this.userService.createUser(userDto);
                return ResponseEntity.status(HttpStatus.CREATED).body(createdUser);

        }

        @GetMapping("/getAll")
        public ResponseEntity<List<User>> getAllUsers() {

                List<User> users =this. userService.getAllUsers();
                return ResponseEntity.ok(users);

        }

        @GetMapping("/get/{id}")
        public ResponseEntity<User> getUserById(@PathVariable long id) {

                User user = this.userService.getUserById(id);
                return ResponseEntity.ok(user);

        }

        @PutMapping("/update/{id}")
        public ResponseEntity<User> updateUser(@PathVariable long id, @RequestBody UserDto userDto) {

                User updatedUser = this.userService.updateUser(id, userDto);
                return ResponseEntity.ok(updatedUser);

        }

        @DeleteMapping("/delete/{id}")
        public ResponseEntity<Void> deleteUserById(@PathVariable long id) {

               this.userService.deleteUserById(id);
                return ResponseEntity.noContent().build();
    }
        
        @GetMapping("/getProductByUserId/{userId}")
        public UserDemoDto getProductByUserId(@PathVariable Long userId)
        {
        	return userService.getProductByUserId(userId);
        }

}
