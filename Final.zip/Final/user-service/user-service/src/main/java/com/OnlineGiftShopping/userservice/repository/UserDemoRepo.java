package com.OnlineGiftShopping.userservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

//import com.OnlineGiftShopping.userservice.entity.User;
import com.OnlineGiftShopping.userservice.entity.UserDemo;

@Repository
public interface UserDemoRepo extends JpaRepository<UserDemo,Long>{

	

}
