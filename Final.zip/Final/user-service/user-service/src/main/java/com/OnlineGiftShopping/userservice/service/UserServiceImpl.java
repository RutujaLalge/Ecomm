package com.OnlineGiftShopping.userservice.service;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
//import org.springframework.web.client.RestTemplate;

import com.OnlineGiftShopping.userservice.communication.UserClient;
import com.OnlineGiftShopping.userservice.dto.ProductDto;
import com.OnlineGiftShopping.userservice.dto.UserDemoDto;
import com.OnlineGiftShopping.userservice.dto.UserDto;

import com.OnlineGiftShopping.userservice.entity.User;
import com.OnlineGiftShopping.userservice.entity.UserDemo;
import com.OnlineGiftShopping.userservice.exception.UserNotFoundException;
import com.OnlineGiftShopping.userservice.repository.UserDemoRepo;
import com.OnlineGiftShopping.userservice.repository.UserRepo;

import java.util.List;


@Service
public class UserServiceImpl implements UserService{

    @Autowired
    private UserRepo userRepo;
    
   
//    @Autowired
//    private ProductService productService;


    @Autowired
    private UserClient userClient;
    
//    @Autowired
//    private ProductClient productClient;

    @Override
    public User createUser(UserDto userDto) {
        User user = new User();
        BeanUtils.copyProperties(userDto,user);
//        user.setPassword(passwordEncoder.encode(userDto.getPassword()));
        User createdUser = this.userRepo.save(user);
        return createdUser;
    }

    @Override
    public List<User> getAllUsers() {
        List<User> users = this.userRepo.findAll();
        return users;
    }

    @Override
    public User getUserById(long id) {
        User user = this.userRepo.findById(id).orElseThrow(() ->
                new UserNotFoundException("User with id " + id + " not found"));
//        Product[] product=userClient.getProduct(user.getId());
//        List<Product> productList=Arrays.stream(product).toList();
//        user.setGetProducts(productList);
        
        
        return user;
    }

    @Override
    public User updateUser(long id, UserDto userDto) {
        User existingUser = this.userRepo.findById(id).orElseThrow(() ->
                new UserNotFoundException("User with id " + id + " not found"));

        existingUser.setName(userDto.getName());
        existingUser.setEmail(userDto.getEmail());
        existingUser.setPhoneNumber(userDto.getPhoneNumber());
        existingUser.setPassword(userDto.getPassword());
        User updatedUser = this.userRepo.save(existingUser);
        return updatedUser;
    }

    @Override
    public void deleteUserById(long id) {

        User user = this.userRepo.findById(id).orElseThrow(() ->
                new UserNotFoundException("User with id " + id + " not found"));

        this.userRepo.delete(user);

    }
    
    @Autowired
    private UserDemoRepo userDemoRepo;
    
    public UserDemoDto getProductByUserId(Long userId)
    {
    	UserDemo userDemo = userDemoRepo.findById(userId).get();
    	Long productId = userDemo.getProductId();
    	ProductDto productDto = userClient.getProductById(productId);
    	User user = userRepo.findById(userId).get();
    	UserDemoDto obj=new UserDemoDto(userId,productDto,user);
    	return obj;
    }
}
